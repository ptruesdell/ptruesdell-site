from django.contrib import admin
from contact_form.models import ContactInfo

# Register your models here.

admin.site.register(ContactInfo)
