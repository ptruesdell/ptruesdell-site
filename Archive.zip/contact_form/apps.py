from django.apps import AppConfig


class ContactFormConfig(AppConfig):
    name = 'contact_form'
